<?php
    $headname = $_POST['headname'];
    $fname = $_POST['fname'];
    $numphone = $_POST['phone'];
    $from = $_POST['city'];
    $Slip = $_POST['slip'];
    $Email = $_POST['email'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Acme&display=swap');
    </style>

<style>
    body{
    padding: 0%;
    margin: 0%;
    font-weight: bold;
    background-color: rgb(235, 203, 144);
}
/* design tap menu */
.top-header{
    font-family: 'Acme', sans-serif;
    background-color: rgb(230, 139, 36);
    font-family: 'Acme', sans-serif;
}
.menu-item-brand{
    color: white;
    text-decoration: none;
    font-size: 3em;
    padding: 30px;
}
.menu1{
    font-size: 20px;
    color: white;
    text-decoration: none;
}
.menu1:hover{ 
    color: gray;
}
.menu2{
    font-size: 20px;
    color: white;
    text-decoration: none;
}
.menu2:hover{
    color: gray;
}
.menu3{
    font-size: 20px;
    color: white;
    text-decoration: none;
}
.menu3:hover{
    color: gray;
}
.menu4{
    font-size: 20px;
    color: white;
    text-decoration: none;
}
.menu4:hover{
    color: red;
}   
fieldset{
    padding: 2cm;
}
.botton{
    background-color: rgb(4, 199, 4);
    border: none;
    font-weight: bold;
    padding: 10px;
    width: 100px;
}
.botton:hover{
    color: red;
    transform: scale(1.1);
}
h1{
    color: gray;
    font-size: 20px;
    padding: 10px;
}
input{
    border-radius: 3px;
    padding: 3px;
    background-color: rgb(238, 238, 238);
}
div {
    font-size: 20px;
}
data {
    font-family: 'Pridi', serif;
}

        </style>
</head>
<body>
<header class="top-header">
        <a class="menu-item-brand" href="index1.html">Love Castus </a>
        <a class="menu1" href="newcastus2.html">New Castus</a>&nbsp;&nbsp;&nbsp;&nbsp;
        <a class="menu2" href="shop3.html">Shop</a>&nbsp;&nbsp;&nbsp;&nbsp;
        <a class="menu3" href="pot4.html">กระถาง</a>&nbsp;&nbsp;&nbsp;&nbsp;
        <a class="menu3" href="seed5.html">เมล็ด</a>&nbsp;&nbsp;&nbsp;&nbsp;
        <a class="menu4" href="sale6.html">Sale</a>&nbsp;&nbsp;&nbsp;&nbsp;
    </header>
    <br>
    <fieldset>
        <legend style="font-size: 30px;"> สำเร็จ <img src="img/190411.png" alt="" width="35px"></legend> 
        <div>ชื่อ-นามสกุล : <?php echo $headname . $fname  ?> </div> <br>
        <div>เบอร์โทร: <?php echo $numphone ?></div> <br>
        <div>E-mail : <?php echo $Email ?></div> <br>
        <div>ที่อยู่ : <?php echo $from ?></div> <br>
        <div>หลักฐานการโอน : <?php echo $Slip ?></div> <br><br><br>
        <img src="img/79.png" alt="" width="50px"> <b>ขอบคุณที่มาอุดหนุน</b> <img src="img/79.png" alt="" width="50px">
        <!-- <link rel="icon" href="/img/190411.png"  > -->

        <img src="img/tree1.png" alt="" width="350px">
        
    </fieldset>
</body>
</html>